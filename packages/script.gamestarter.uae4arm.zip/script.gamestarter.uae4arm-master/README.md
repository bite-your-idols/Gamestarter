# Gamestarter: UAE4ARM
Launch [Gamestarter's](https://github.com/bite-your-idols/gamestarter-openelec) RetroArch frontend as an addon for Kodi in OpenELEC for Raspberry Pi.
