import xbmcaddon
import xbmcgui
import os

os.system("/storage/emulators/scripts/gamestarter.sh start")