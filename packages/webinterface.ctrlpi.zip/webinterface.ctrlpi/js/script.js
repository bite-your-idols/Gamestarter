var ip= window.location.href.split(":8080")[0];
//console.log(ip,destino);

function sendKodi(orden){
	$.ajax({
		url: ip+":8080/jsonrpc?request={%22jsonrpc%22:%20%222.0%22,%20%22method%22:%20%22"+orden+"%22,%20%22id%22:%201}", 
		 success: function (data, status,xhr) {
	    	//console.log("ok: ", xhr.status, data);
	    	data=JSON.stringify(data, undefined, 4);
	    	console.log(data);

		}, error: function(xhr,status,error){
			console.log("Error: ", xhr.status,xhr.responseText)
		}
	});

	//data=JSON.stringify(data, undefined, 4);

	//console.log(data);
}

$( document ).ready(function() {
	$('.btn-hyperion').click(function(e){
		e.preventDefault();
		window.location = ip+":8080/hyperion.remote/";
	});

    $('.btn-transmission').click(function(e){
		e.preventDefault();
		window.location = ip+":9091";
	});

	$('.btn-update').click(function(e){
		e.preventDefault();
		//window.location = ip+":8080/jsonrpc?request={%22jsonrpc%22:%20%222.0%22,%20%22method%22:%20%22System.Shutdown%22,%20%22id%22:%201}";
		sendKodi("VideoLibrary.Scan");
	});

	$('.btn-reboot').click(function(e){
		e.preventDefault();
		sendKodi("System.Reboot");
		//window.location = ip+":8080/jsonrpc?request={%22jsonrpc%22:%20%222.0%22,%20%22method%22:%20%22System.Reboot%22,%20%22id%22:%201}";
	});

	$('.btn-shutdown').click(function(e){
		e.preventDefault();
		//window.location = ip+":8080/jsonrpc?request={%22jsonrpc%22:%20%222.0%22,%20%22method%22:%20%22System.Shutdown%22,%20%22id%22:%201}";
		sendKodi("System.Shutdown");
	});
});