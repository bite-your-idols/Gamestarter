Theme by Smithers- variation of the Simple Theme.

It is nothing revolutionary, just a different take on the standard ‘Simple’ theme and I have also modified each system theme to only show a picture for each game (i.e. no extra text appears on the screen, only a screenshot / box art).

I recommend setting ES transition to ‘Slide’ and also turn off the on-screen help text for the cleanest look.