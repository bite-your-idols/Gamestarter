#!/bin/sh

# . /etc/profile

MY_DIR="/storage/emulators/roms/ports/SuperCrateBox"

chmod 777 $MY_DIR/*

$MY_DIR/SuperCrateBox