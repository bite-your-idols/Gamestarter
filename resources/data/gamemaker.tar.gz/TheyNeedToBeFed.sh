#!/bin/sh

# . /etc/profile

MY_DIR="/storage/emulators/roms/ports/TheyNeedToBeFed"

chmod a+x $MY_DIR/*

$MY_DIR/TheyNeedToBeFed
