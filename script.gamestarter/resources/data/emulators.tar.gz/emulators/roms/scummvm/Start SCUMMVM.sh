#!/bin/sh
# . /etc/profile

# RETROARCH_APP="/storage/.kodi/addons/script.gamestarter/resources/bin/retroarch"
# RETROARCH_CONFIG_FILE="/storage/.kodi/userdata/addon_data/script.gamestarter/retroarch/retroarch.cfg"
# RETROARCH_CORE_DIR="/storage/.kodi/addons/script.gamestarter/resources/bin/libretro-cores"

# $RETROARCH_APP -c $RETROARCH_CONFIG_FILE -L $RETROARCH_CORE_DIR/scummvm_libretro.so

echo "launch scummvm!"